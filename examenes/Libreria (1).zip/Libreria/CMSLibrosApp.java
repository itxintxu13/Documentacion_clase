import java.util.Scanner;

class Libro {
    String titulo;
    String isbn;
    int numeroPaginas;
    boolean formatoDigital; // true = digital, false = papel

    public Libro(String titulo, String isbn, int numeroPaginas, boolean formatoDigital) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.numeroPaginas = numeroPaginas;
        this.formatoDigital = formatoDigital;
    }

    public void mostrarResumen() {
        System.out.println("\n Resumen del libro:");
        System.out.println("Título: " + titulo);
        System.out.println("ISBN: " + isbn);
        System.out.println("Número de páginas: " + numeroPaginas);
        System.out.println("Formato: " + (formatoDigital ? "Digital" : "Papel"));
    }
}

public class CMSLibrosApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String titulo;
        String isbn;
        int numeroPaginas;
        boolean formatoDigital;

        // Validar TÍTULO
        while (true) {
            System.out.print("Introduce el título del libro (3-150 caracteres): ");
            titulo = sc.nextLine().trim();
            if (titulo.length() >= 3 && titulo.length() <= 150) break;
            System.out.println("Título inválido. Inténtalo de nuevo.");
        }

        // Validar ISBN
        while (true) {
            System.out.print("Introduce el ISBN (exactamente 10 dígitos): ");
            isbn = sc.nextLine().trim();
            if (isbn.matches("\\d{10}")) break;
            System.out.println("ISBN inválido. Debe tener exactamente 10 números.");
        }

        // Validar número de páginas
        while (true) {
            System.out.print("Introduce el número de páginas (mínimo 1): ");
            try {
                numeroPaginas = Integer.parseInt(sc.nextLine());
                if (numeroPaginas >= 1) break;
            } catch (NumberFormatException e) {}
            System.out.println("Número de páginas inválido. Debe ser un número entero mayor que 0.");
        }

        // Validar formato
        while (true) {
            System.out.print("¿El formato es digital? (true / false): ");
            String input = sc.nextLine().trim().toLowerCase();
            if (input.equals("true")) {
                formatoDigital = true;
                break;
            } else if (input.equals("false")) {
                formatoDigital = false;
                break;
            }
            System.out.println("Formato inválido. Escribe 'true' para digital o 'false' para papel.");
        }

        // Crear libro y mostrar resumen
        Libro libro = new Libro(titulo, isbn, numeroPaginas, formatoDigital);
        libro.mostrarResumen();

        // Confirmación
        System.out.print("¿Deseas guardar este libro en el CMS? (s/n): ");
        String confirmar = sc.nextLine().trim().toLowerCase();

        if (confirmar.equals("s")) {
            System.out.println("Libro guardado con éxito en el CMS.");
            // Aquí podrías añadirlo a una base de datos, lista, archivo, etc.
        } else {
            System.out.println("Registro cancelado.");
        }

        sc.close();
    }
}
