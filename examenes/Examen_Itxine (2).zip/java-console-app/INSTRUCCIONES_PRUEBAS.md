# Instrucciones para Realizar Pruebas en la Aplicación de Biblioteca

Este documento proporciona instrucciones detalladas sobre cómo ejecutar las diferentes pruebas implementadas en la aplicación de biblioteca.

## 1. Pruebas Unitarias

Las pruebas unitarias verifican componentes individuales del código. Se han implementado pruebas para el modelo, repositorio y servicio.

### Requisitos previos

- Java 17 o superior instalado
- Maven instalado

### Ejecutar pruebas unitarias

```bash
mvn test
```

Este comando ejecutará todas las pruebas unitarias del proyecto y mostrará los resultados en la consola.

### Pruebas implementadas

- **BibliotecaServiceTest**: Prueba las funcionalidades del servicio de biblioteca:
  - `testRegistrarLibro`: Verifica el registro correcto de un libro
  - `testRegistrarUsuario`: Verifica el registro correcto de un usuario
  - `testPrestarLibro`: Verifica el proceso de préstamo de un libro a un usuario

## 2. Pruebas de Integración con Postman

Se ha creado una colección de Postman para probar los endpoints de la API REST.

### Requisitos previos

- Postman instalado (descarga desde [postman.com](https://www.postman.com/downloads/))
- Aplicación en ejecución (`mvn spring-boot:run`)

### Importar la colección en Postman

1. Abre Postman
2. Haz clic en "Import" (botón en la esquina superior izquierda)
3. Selecciona el archivo `src/test/resources/Biblioteca_API_Tests.postman_collection.json`
4. La colección "Biblioteca API Tests" aparecerá en tu panel de colecciones

### Ejecutar las pruebas de API

1. Asegúrate de que la aplicación esté en ejecución con `mvn spring-boot:run`
2. En Postman, abre la colección "Biblioteca API Tests"
3. Puedes ejecutar solicitudes individuales o ejecutar toda la colección:
   - Para ejecutar una solicitud individual, selecciónala y haz clic en "Send"
   - Para ejecutar toda la colección, haz clic en los tres puntos (...) junto al nombre de la colección, selecciona "Run collection" y sigue las instrucciones

### Endpoints disponibles para pruebas

#### Libros
- GET `/libros`: Obtener todos los libros
- POST `/libros`: Crear un nuevo libro
- GET `/libros/{id}`: Obtener un libro por ID
- PUT `/libros/{id}`: Actualizar un libro existente
- DELETE `/libros/{id}`: Eliminar un libro

#### Usuarios
- GET `/usuarios`: Obtener todos los usuarios
- POST `/usuarios`: Crear un nuevo usuario
- GET `/usuarios/{id}`: Obtener un usuario por ID
- PUT `/usuarios/{id}`: Actualizar un usuario existente
- DELETE `/usuarios/{id}`: Eliminar un usuario

#### Préstamos
- GET `/prestamos`: Obtener todos los préstamos
- POST `/prestamos`: Crear un nuevo préstamo
- GET `/prestamos/{id}`: Obtener un préstamo por ID
- PUT `/prestamos/{id}`: Actualizar un préstamo existente
- DELETE `/prestamos/{id}`: Eliminar un préstamo

## 3. Pruebas de Sistema

Las pruebas de sistema verifican el flujo completo de la aplicación y la persistencia de datos.

### Requisitos previos

- MySQL Server instalado y configurado según `README_MYSQL.md`
- Aplicación configurada para usar MySQL

### Ejecutar pruebas de sistema

1. Inicia la aplicación con MySQL:
   ```bash
   mvn spring-boot:run
   ```

2. Realiza las siguientes operaciones para probar el flujo completo:

   a. **Registrar un libro**:
      - Usa la consola o el endpoint POST `/libros`
   
   b. **Registrar un usuario**:
      - Usa la consola o el endpoint POST `/usuarios`
   
   c. **Crear un préstamo**:
      - Usa la consola o el endpoint POST `/prestamos`
   
   d. **Verificar la persistencia**:
      - Consulta la base de datos MySQL:
      ```sql
      USE bibliotecadb;
      SELECT * FROM libro;
      SELECT * FROM usuario;
      SELECT * FROM prestamo;
      ```

## 4. Verificación de la Consola

Para probar la interfaz de consola:

1. Inicia la aplicación:
   ```bash
   mvn spring-boot:run
   ```

2. La aplicación mostrará un menú en la consola con opciones para:
   - Registrar libros
   - Registrar usuarios
   - Realizar préstamos
   - Ver libros, usuarios y préstamos

3. Sigue las instrucciones en pantalla para interactuar con la aplicación

## Notas Adicionales

- Las pruebas unitarias utilizan Mockito para simular dependencias, lo que permite probar componentes de forma aislada
- La colección de Postman puede ser modificada para adaptarse a cambios en la API
- Para un entorno de producción, se recomienda configurar un entorno de pruebas separado