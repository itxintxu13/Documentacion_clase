import modelo.*;
import servicio.Biblioteca;
import java.util.Scanner;

public class BibliotecaApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();
        int opcion;

        do {
            System.out.println("\n--- Menú Biblioteca ---");
            System.out.println("1. Registrar libro");
            System.out.println("2. Registrar usuario");
            System.out.println("3. Prestar libro");
            System.out.println("4. Mostrar libros");
            System.out.println("5. Mostrar usuarios");
            System.out.println("6. Mostrar préstamos");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> biblioteca.registrarLibro(scanner);
                case 2 -> biblioteca.registrarUsuario(scanner);
                case 3 -> biblioteca.prestarLibro(scanner);
                case 4 -> biblioteca.mostrarLibros();
                case 5 -> biblioteca.mostrarUsuarios();
                case 6 -> biblioteca.mostrarPrestamos();
            }
        } while (opcion != 0);
    }
}