// Variables globales
const API_URL = {
    LIBROS: '/libros',
    USUARIOS: '/usuarios',
    PRESTAMOS: '/prestamos'
};

// Elementos DOM
const sections = {
    welcome: document.getElementById('welcome'),
    libros: document.getElementById('libros-section'),
    usuarios: document.getElementById('usuarios-section'),
    prestamos: document.getElementById('prestamos-section')
};

// Navegación
document.getElementById('nav-libros').addEventListener('click', () => showSection('libros'));
document.getElementById('nav-usuarios').addEventListener('click', () => showSection('usuarios'));
document.getElementById('nav-prestamos').addEventListener('click', () => showSection('prestamos'));

// Cards del dashboard
document.getElementById('card-libros').addEventListener('click', () => showSection('libros'));
document.getElementById('card-usuarios').addEventListener('click', () => showSection('usuarios'));
document.getElementById('card-prestamos').addEventListener('click', () => showSection('prestamos'));

// Botones para mostrar formularios
document.getElementById('btn-nuevo-libro').addEventListener('click', () => toggleFormVisibility('libro'));
document.getElementById('btn-nuevo-usuario').addEventListener('click', () => toggleFormVisibility('usuario'));
document.getElementById('btn-nuevo-prestamo').addEventListener('click', () => toggleFormVisibility('prestamo'));

// Botones para cancelar formularios
document.getElementById('btn-cancelar-libro').addEventListener('click', () => toggleFormVisibility('libro', false));
document.getElementById('btn-cancelar-usuario').addEventListener('click', () => toggleFormVisibility('usuario', false));
document.getElementById('btn-cancelar-prestamo').addEventListener('click', () => toggleFormVisibility('prestamo', false));

// Formularios
document.getElementById('libro-form').addEventListener('submit', handleLibroSubmit);
document.getElementById('usuario-form').addEventListener('submit', handleUsuarioSubmit);
document.getElementById('prestamo-form').addEventListener('submit', handlePrestamoSubmit);

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    // Cargar datos iniciales
    loadLibros();
    loadUsuarios();
    loadPrestamos();
    
    // Configurar fecha actual en formulario de préstamo
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('fechaPrestamo').value = today;
    
    // Fecha de devolución por defecto (15 días después)
    const devolucion = new Date();
    devolucion.setDate(devolucion.getDate() + 15);
    document.getElementById('fechaDevolucion').value = devolucion.toISOString().split('T')[0];
});

// Funciones
function showSection(sectionName) {
    // Ocultar todas las secciones
    Object.values(sections).forEach(section => {
        section.classList.remove('active-section');
        section.classList.add('hidden-section');
    });
    
    // Mostrar la sección seleccionada
    sections[sectionName].classList.remove('hidden-section');
    sections[sectionName].classList.add('active-section');
}

function toggleFormVisibility(formType, show = true) {
    const formContainer = document.getElementById(`${formType}-form-container`);
    
    if (show) {
        formContainer.classList.remove('hidden');
        
        // Si es el formulario de préstamo, cargar las opciones de usuarios y libros
        if (formType === 'prestamo') {
            loadUsuariosOptions();
            loadLibrosOptions();
        }
    } else {
        formContainer.classList.add('hidden');
        // Resetear el formulario
        document.getElementById(`${formType}-form`).reset();
    }
}

// Funciones para cargar datos
async function loadLibros() {
    try {
        const response = await fetch(API_URL.LIBROS);
        const libros = await response.json();
        
        const tbody = document.querySelector('#libros-table tbody');
        tbody.innerHTML = '';
        
        libros.forEach(libro => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${libro.id}</td>
                <td>${libro.titulo}</td>
                <td>${libro.autor}</td>
                <td>${libro.isbn}</td>
                <td>${libro.anio}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error al cargar libros:', error);
    }
}

async function loadUsuarios() {
    try {
        const response = await fetch(API_URL.USUARIOS);
        const usuarios = await response.json();
        
        const tbody = document.querySelector('#usuarios-table tbody');
        tbody.innerHTML = '';
        
        usuarios.forEach(usuario => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${usuario.id}</td>
                <td>${usuario.nombre}</td>
                <td>${usuario.dni}</td>
                <td>${usuario.correo}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error al cargar usuarios:', error);
    }
}

async function loadPrestamos() {
    try {
        const response = await fetch(API_URL.PRESTAMOS);
        const prestamos = await response.json();
        
        const tbody = document.querySelector('#prestamos-table tbody');
        tbody.innerHTML = '';
        
        prestamos.forEach(prestamo => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${prestamo.id}</td>
                <td>${prestamo.usuario.nombre}</td>
                <td>${prestamo.libro.titulo}</td>
                <td>${formatDate(prestamo.fechaPrestamo)}</td>
                <td>${formatDate(prestamo.fechaDevolucion)}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error al cargar préstamos:', error);
    }
}

async function loadUsuariosOptions() {
    try {
        const response = await fetch(API_URL.USUARIOS);
        const usuarios = await response.json();
        
        const select = document.getElementById('usuario-select');
        // Mantener solo la opción por defecto
        select.innerHTML = '<option value="">Seleccione un usuario</option>';
        
        usuarios.forEach(usuario => {
            const option = document.createElement('option');
            option.value = usuario.id;
            option.textContent = `${usuario.nombre} (${usuario.dni})`;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error al cargar opciones de usuarios:', error);
    }
}

async function loadLibrosOptions() {
    try {
        const response = await fetch(API_URL.LIBROS);
        const libros = await response.json();
        
        const select = document.getElementById('libro-select');
        // Mantener solo la opción por defecto
        select.innerHTML = '<option value="">Seleccione un libro</option>';
        
        libros.forEach(libro => {
            const option = document.createElement('option');
            option.value = libro.id;
            option.textContent = `${libro.titulo} (${libro.autor})`;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error al cargar opciones de libros:', error);
    }
}

// Funciones para manejar envío de formularios
async function handleLibroSubmit(event) {
    event.preventDefault();
    
    const formData = {
        titulo: document.getElementById('titulo').value,
        autor: document.getElementById('autor').value,
        isbn: document.getElementById('isbn').value,
        anio: parseInt(document.getElementById('anio').value)
    };
    
    try {
        const response = await fetch(API_URL.LIBROS, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            // Ocultar formulario y recargar datos
            toggleFormVisibility('libro', false);
            loadLibros();
            alert('Libro registrado con éxito');
        } else {
            alert('Error al registrar el libro');
        }
    } catch (error) {
        console.error('Error al enviar formulario de libro:', error);
        alert('Error al registrar el libro');
    }
}

async function handleUsuarioSubmit(event) {
    event.preventDefault();
    
    const formData = {
        nombre: document.getElementById('nombre').value,
        dni: document.getElementById('dni').value,
        correo: document.getElementById('correo').value
    };
    
    try {
        const response = await fetch(API_URL.USUARIOS, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            // Ocultar formulario y recargar datos
            toggleFormVisibility('usuario', false);
            loadUsuarios();
            alert('Usuario registrado con éxito');
        } else {
            alert('Error al registrar el usuario');
        }
    } catch (error) {
        console.error('Error al enviar formulario de usuario:', error);
        alert('Error al registrar el usuario');
    }
}

async function handlePrestamoSubmit(event) {
    event.preventDefault();
    
    const usuarioId = document.getElementById('usuario-select').value;
    const libroId = document.getElementById('libro-select').value;
    
    if (!usuarioId || !libroId) {
        alert('Debe seleccionar un usuario y un libro');
        return;
    }
    
    const formData = {
        usuario: { id: parseInt(usuarioId) },
        libro: { id: parseInt(libroId) },
        fechaPrestamo: document.getElementById('fechaPrestamo').value,
        fechaDevolucion: document.getElementById('fechaDevolucion').value
    };
    
    try {
        const response = await fetch(API_URL.PRESTAMOS, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (response.ok) {
            // Ocultar formulario y recargar datos
            toggleFormVisibility('prestamo', false);
            loadPrestamos();
            alert('Préstamo registrado con éxito');
        } else {
            alert('Error al registrar el préstamo');
        }
    } catch (error) {
        console.error('Error al enviar formulario de préstamo:', error);
        alert('Error al registrar el préstamo');
    }
}

// Funciones de utilidad
function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString();
}