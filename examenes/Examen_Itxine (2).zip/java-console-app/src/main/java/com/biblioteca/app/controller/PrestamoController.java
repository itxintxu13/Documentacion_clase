package com.biblioteca.app.controller;

import com.biblioteca.app.model.Prestamo;
import com.biblioteca.app.service.BibliotecaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/prestamos")
public class PrestamoController {

    private final BibliotecaService bibliotecaService;

    public PrestamoController(BibliotecaService bibliotecaService) {
        this.bibliotecaService = bibliotecaService;
    }

    @GetMapping
    public ResponseEntity<List<Prestamo>> getAllPrestamos() {
        return ResponseEntity.ok(bibliotecaService.getAllPrestamos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Prestamo> getPrestamoById(@PathVariable Long id) {
        Prestamo prestamo = bibliotecaService.getPrestamoById(id);
        if (prestamo != null) {
            return ResponseEntity.ok(prestamo);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<Prestamo>> getPrestamosByUsuarioId(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(bibliotecaService.getPrestamosByUsuarioId(usuarioId));
    }

    @PostMapping
    public ResponseEntity<Prestamo> createPrestamo(@RequestBody Prestamo prestamo) {
        return new ResponseEntity<>(bibliotecaService.savePrestamo(prestamo), HttpStatus.CREATED);
    }
}