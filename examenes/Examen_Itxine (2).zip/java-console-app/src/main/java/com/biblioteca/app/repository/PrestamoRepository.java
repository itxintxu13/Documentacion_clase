package com.biblioteca.app.repository;

import com.biblioteca.app.model.Prestamo;
import com.biblioteca.app.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PrestamoRepository extends JpaRepository<Prestamo, Long> {
    // Método para encontrar préstamos por usuario
    List<Prestamo> findByUsuario(Usuario usuario);
    
    // Método para encontrar préstamos por ID de usuario
    List<Prestamo> findByUsuarioId(Long usuarioId);
}