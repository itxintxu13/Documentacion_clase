package com.biblioteca.app.console;

import com.biblioteca.app.service.BibliotecaService;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class BibliotecaConsoleApp {

    private static BibliotecaService bibliotecaService;

    public BibliotecaConsoleApp(BibliotecaService bibliotecaService) {
        BibliotecaConsoleApp.bibliotecaService = bibliotecaService;
    }

    // Banner ASCII art para la biblioteca
    private static final String BANNER = 
        "  ____   _   ____   _     _   _____  _____  _____   ____      _      \n" +
        " | __ ) (_) | __ ) | |   (_) / _ \\ |_   _|| ____| / ___|    / \\     \n" +
        " |  _ \\ | | |  _ \\ | |   | || | | |  | |  |  _|  / |       / _ \\    \n" +
        " | |_) || | | |_) || |___| || |_| |  | |  | |___ | |___   / ___ \\   \n" +
        " |____/ |_| |____/ |_____|_| \\___/   |_|  |_____| \\____|  /_/   \\_\\  \n" +
        "                      BIBLIOTECA                                     ";


    // Decoradores para el menú
    private static final String MENU_SEPARATOR = "╔════════════════════════════════════╗";
    private static final String MENU_FOOTER = "╚════════════════════════════════════╝";
    private static final String MENU_ITEM_PREFIX = "║  ";
    private static final String MENU_ITEM_SUFFIX = "  ║";

    public static void main(String[] args) {
        // Si se ejecuta directamente sin Spring, espera a que el servicio sea inyectado
        while (bibliotecaService == null) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            // Limpiar la consola
            System.out.print("\033[H\033[2J");
            System.out.flush();
            
            // Mostrar banner y menú
            System.out.println(BANNER);
            System.out.println(MENU_SEPARATOR);
            System.out.println(MENU_ITEM_PREFIX + "       MENÚ PRINCIPAL       " + MENU_ITEM_SUFFIX);
            System.out.println(MENU_SEPARATOR);
            System.out.println(MENU_ITEM_PREFIX + " 1. Registrar Libros         " + MENU_ITEM_SUFFIX);
            System.out.println(MENU_ITEM_PREFIX + " 2. Registrar Usuarios       " + MENU_ITEM_SUFFIX);
            System.out.println(MENU_ITEM_PREFIX + " 3. Prestar Libros a usuarios " + MENU_ITEM_SUFFIX);
            System.out.println(MENU_ITEM_PREFIX + " 0. Salir                    " + MENU_ITEM_SUFFIX);
            System.out.println(MENU_FOOTER);
            System.out.print("\nOpción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    bibliotecaService.registrarLibro(scanner);
                    break;
                case 2:
                    bibliotecaService.registrarUsuario(scanner);
                    break;
                case 3:
                    bibliotecaService.prestarLibro(scanner);
                    break;
            }
        } while (opcion != 0);
    }
}

