package com.biblioteca.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BibliotecaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BibliotecaApplication.class, args);
    }
    
    @Bean
    public CommandLineRunner consoleApp() {
        return args -> {
            // Aquí se iniciará la aplicación de consola cuando se ejecute Spring Boot
            System.out.println("\nAplicación de Biblioteca iniciada en modo consola y web.\n");
            System.out.println("Accede a la API REST en: http://localhost:8080\n");
            
            // Iniciar la aplicación de consola en un hilo separado
            Thread consoleThread = new Thread(() -> {
                com.biblioteca.app.console.BibliotecaConsoleApp.main(args);
            });
            consoleThread.start();
        };
    }
}