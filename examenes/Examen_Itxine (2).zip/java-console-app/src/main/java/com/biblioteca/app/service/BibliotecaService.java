package com.biblioteca.app.service;

import com.biblioteca.app.model.Libro;
import com.biblioteca.app.model.Prestamo;
import com.biblioteca.app.model.Usuario;
import com.biblioteca.app.model.UsuarioRegular;
import com.biblioteca.app.repository.LibroRepository;
import com.biblioteca.app.repository.PrestamoRepository;
import com.biblioteca.app.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

@Service
public class BibliotecaService {

    private final LibroRepository libroRepository;
    private final UsuarioRepository usuarioRepository;
    private final PrestamoRepository prestamoRepository;

    public BibliotecaService(LibroRepository libroRepository, UsuarioRepository usuarioRepository, PrestamoRepository prestamoRepository) {
        this.libroRepository = libroRepository;
        this.usuarioRepository = usuarioRepository;
        this.prestamoRepository = prestamoRepository;
    }

    // ASCII art para formularios
    private static final String REGISTRO_LIBRO_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   REGISTRO DE NUEVO LIBRO                               │
        └───────────────────────────────────────────────────────────┘
    """;
    
    private static final String REGISTRO_USUARIO_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   REGISTRO DE NUEVO USUARIO                             │
        └───────────────────────────────────────────────────────────┘
    """;
    
    private static final String REGISTRO_PRESTAMO_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   REGISTRO DE NUEVO PRÉSTAMO                            │
        └───────────────────────────────────────────────────────────┘
    """;
    
    private static final String EXITO_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   OPERACIÓN COMPLETADA CON ÉXITO                        │
        └───────────────────────────────────────────────────────────┘
    """;
    
    private static final String ERROR_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   ERROR EN LA OPERACIÓN                                 │
        └───────────────────────────────────────────────────────────┘
    """;

    // Métodos para la aplicación de consola
    public void registrarLibro(Scanner sc) {
        System.out.println(REGISTRO_LIBRO_BANNER);
        
        System.out.println("┌───────────────────────────────────────────────────────────┐");
        System.out.print("│  Título: ");
        String titulo = sc.nextLine();
        System.out.println("├───────────────────────────────────────────────────────────┤");
        
        System.out.print("│  Autor: ");
        String autor = sc.nextLine();
        System.out.println("├───────────────────────────────────────────────────────────┤");
        
        System.out.print("│  ISBN: ");
        String isbn = sc.nextLine();
        System.out.println("├───────────────────────────────────────────────────────────┤");
        
        System.out.print("│  Año: ");
        int anio = sc.nextInt(); sc.nextLine();
        System.out.println("└───────────────────────────────────────────────────────────┘");
        
        Libro libro = new Libro(titulo, autor, isbn, anio);
        libroRepository.save(libro);
        
        System.out.println(EXITO_BANNER);
        System.out.println("Libro \"" + titulo + "\" registrado correctamente con ID: " + libro.getId());
        esperarEnter();
    }

    public void registrarUsuario(Scanner sc) {
        System.out.println(REGISTRO_USUARIO_BANNER);
        
        System.out.println("┌───────────────────────────────────────────────────────────┐");
        System.out.print("│  Nombre: ");
        String nombre = sc.nextLine();
        System.out.println("├───────────────────────────────────────────────────────────┤");
        
        System.out.print("│  DNI: ");
        String dni = sc.nextLine();
        System.out.println("├───────────────────────────────────────────────────────────┤");
        
        System.out.print("│  Correo: ");
        String correo = sc.nextLine();
        System.out.println("└───────────────────────────────────────────────────────────┘");
        
        Usuario usuario = new UsuarioRegular(nombre, dni, correo);
        usuarioRepository.save(usuario);
        
        System.out.println(EXITO_BANNER);
        System.out.println("Usuario \"" + nombre + "\" registrado correctamente con ID: " + usuario.getId());
        esperarEnter();
    }

    public void prestarLibro(Scanner sc) {
        System.out.println(REGISTRO_PRESTAMO_BANNER);
        
        List<Usuario> usuarios = usuarioRepository.findAll();
        List<Libro> libros = libroRepository.findAll();
        
        if (usuarios.isEmpty() || libros.isEmpty()) {
            System.out.println(ERROR_BANNER);
            System.out.println("Debes registrar al menos un usuario y un libro antes de realizar un préstamo.");
            esperarEnter();
            return;
        }
        
        // Mostrar usuarios disponibles
        System.out.println("┌───────────────────────────────────────────────────────────┐");
        System.out.println("│  SELECCIONE USUARIO                                     │");
        System.out.println("└───────────────────────────────────────────────────────────┘");
        
        System.out.println("┌─────┬────────────────────────────┬──────────────────┬─────────────────────────┐");
        System.out.println("│ IDX │          NOMBRE           │       DNI        │         CORREO          │");
        System.out.println("├─────┼────────────────────────────┼──────────────────┼─────────────────────────┤");
        
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario usuario = usuarios.get(i);
            System.out.printf("│ %-3d │ %-26s │ %-14s │ %-23s │\n", 
                i, 
                truncateString(usuario.getNombre(), 26), 
                truncateString(usuario.getDni(), 14), 
                truncateString(usuario.getCorreo(), 23));
        }
        
        System.out.println("└─────┴────────────────────────────┴──────────────────┴─────────────────────────┘");
        System.out.print("Seleccione usuario (índice o nombre): ");
        String seleccion = sc.nextLine();
        
        int idxUsuario = -1;
        
        // Intentar convertir a índice
        try {
            idxUsuario = Integer.parseInt(seleccion);
            // Validar que el índice esté en rango
            if (idxUsuario < 0 || idxUsuario >= usuarios.size()) {
                System.out.println(ERROR_BANNER);
                System.out.println("Índice de usuario inválido.");
                esperarEnter();
                return;
            }
        } catch (NumberFormatException e) {
            // Si no es un número, buscar por nombre
            boolean encontrado = false;
            for (int i = 0; i < usuarios.size(); i++) {
                if (usuarios.get(i).getNombre().toLowerCase().contains(seleccion.toLowerCase())) {
                    idxUsuario = i;
                    encontrado = true;
                    break;
                }
            }
            
            if (!encontrado) {
                System.out.println(ERROR_BANNER);
                System.out.println("No se encontró ningún usuario con ese nombre.");
                esperarEnter();
                return;
            }
        }

        // Mostrar libros disponibles
        System.out.println("\n┌───────────────────────────────────────────────────────────┐");
        System.out.println("│  SELECCIONE LIBRO                                       │");
        System.out.println("└───────────────────────────────────────────────────────────┘");
        
        System.out.println("┌─────┬────────────────────────────┬────────────────────┬──────────────┬──────┐");
        System.out.println("│ IDX │          TÍTULO           │       AUTOR        │     ISBN     │ AÑO  │");
        System.out.println("├─────┼────────────────────────────┼────────────────────┼──────────────┼──────┤");
        
        for (int i = 0; i < libros.size(); i++) {
            Libro libro = libros.get(i);
            System.out.printf("│ %-3d │ %-26s │ %-18s │ %-12s │ %-4d │\n", 
                i, 
                truncateString(libro.getTitulo(), 26), 
                truncateString(libro.getAutor(), 18), 
                truncateString(libro.getIsbn(), 12), 
                libro.getAnio());
        }
        
        System.out.println("└─────┴────────────────────────────┴────────────────────┴──────────────┴──────┘");
        System.out.print("Seleccione libro (índice o título): ");
        String seleccionLibro = sc.nextLine();
        
        int idxLibro = -1;
        
        // Intentar convertir a índice
        try {
            idxLibro = Integer.parseInt(seleccionLibro);
            // Validar que el índice esté en rango
            if (idxLibro < 0 || idxLibro >= libros.size()) {
                System.out.println(ERROR_BANNER);
                System.out.println("Índice de libro inválido.");
                esperarEnter();
                return;
            }
        } catch (NumberFormatException e) {
            // Si no es un número, buscar por título
            boolean encontrado = false;
            for (int i = 0; i < libros.size(); i++) {
                if (libros.get(i).getTitulo().toLowerCase().contains(seleccionLibro.toLowerCase())) {
                    idxLibro = i;
                    encontrado = true;
                    break;
                }
            }
            
            if (!encontrado) {
                System.out.println(ERROR_BANNER);
                System.out.println("No se encontró ningún libro con ese título.");
                esperarEnter();
                return;
            }
        }

        // Solicitar fechas de préstamo y devolución
        System.out.println("\n┌───────────────────────────────────────────────────────────┐");
        System.out.println("│  FECHAS DE PRÉSTAMO                                     │");
        System.out.println("└───────────────────────────────────────────────────────────┘");
        
        LocalDate hoy = LocalDate.now();
        LocalDate fechaPrestamo = hoy;
        LocalDate fechaDevolucion = hoy.plusDays(15); // Inicializar con un valor predeterminado
        
        // Mostrar fecha actual como predeterminada para el préstamo
        System.out.println("Fecha de préstamo predeterminada: " + hoy + " (fecha actual)");
        System.out.print("¿Desea usar esta fecha? (S/N): ");
        String respuesta = sc.nextLine();
        
        if (respuesta.equalsIgnoreCase("N")) {
            boolean fechaValida = false;
            while (!fechaValida) {
                try {
                    System.out.print("Ingrese fecha de préstamo (formato YYYY-MM-DD): ");
                    String fechaStr = sc.nextLine();
                    fechaPrestamo = LocalDate.parse(fechaStr);
                    fechaValida = true;
                } catch (Exception e) {
                    System.out.println("Formato de fecha inválido. Use el formato YYYY-MM-DD.");
                }
            }
        }
        
        // Fecha de devolución predeterminada (15 días después)
        LocalDate devolucionPredeterminada = fechaPrestamo.plusDays(15);
        System.out.println("\nFecha de devolución predeterminada: " + devolucionPredeterminada + " (15 días después)");
        System.out.print("¿Desea usar esta fecha? (S/N): ");
        respuesta = sc.nextLine();
        
        if (respuesta.equalsIgnoreCase("N")) {
            boolean fechaValida = false;
            while (!fechaValida) {
                try {
                    System.out.print("Ingrese fecha de devolución (formato YYYY-MM-DD): ");
                    String fechaStr = sc.nextLine();
                    fechaDevolucion = LocalDate.parse(fechaStr);
                    
                    // Validar que la fecha de devolución sea posterior a la de préstamo
                    if (fechaDevolucion.isBefore(fechaPrestamo)) {
                        System.out.println("La fecha de devolución debe ser posterior a la fecha de préstamo.");
                    } else {
                        fechaValida = true;
                    }
                } catch (Exception e) {
                    System.out.println("Formato de fecha inválido. Use el formato YYYY-MM-DD.");
                }
            }
        } else {
            fechaDevolucion = devolucionPredeterminada;
        }
        
        // Crear el préstamo
        Prestamo prestamo = new Prestamo(usuarios.get(idxUsuario), libros.get(idxLibro), fechaPrestamo, fechaDevolucion);
        prestamoRepository.save(prestamo);
        
        System.out.println(EXITO_BANNER);
        System.out.println("Préstamo registrado correctamente con ID: " + prestamo.getId());
        System.out.println("Libro: " + libros.get(idxLibro).getTitulo());
        System.out.println("Usuario: " + usuarios.get(idxUsuario).getNombre());
        System.out.println("Fecha de préstamo: " + fechaPrestamo);
        System.out.println("Fecha de devolución: " + fechaDevolucion);
        esperarEnter();
    }

    // ASCII art para secciones
    private static final String LIBROS_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   CATÁLOGO DE LIBROS                                    │
        └───────────────────────────────────────────────────────────┘
    """;
    
    private static final String USUARIOS_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   REGISTRO DE USUARIOS                                  │
        └───────────────────────────────────────────────────────────┘
    """;
    
    private static final String PRESTAMOS_BANNER = """
        ┌───────────────────────────────────────────────────────────┐
        │   REGISTRO DE PRÉSTAMOS                                 │
        └───────────────────────────────────────────────────────────┘
    """;
    
    public void mostrarLibros() {
        System.out.println(LIBROS_BANNER);
        List<Libro> libros = libroRepository.findAll();
        
        if (libros.isEmpty()) {
            System.out.println("\nNo hay libros registrados en el sistema.\n");
            return;
        }
        
        System.out.println("┌─────────┬────────────────────────────┬────────────────────┬──────────────┬──────┐");
        System.out.println("│   ID    │          TÍTULO           │       AUTOR        │     ISBN     │ AÑO  │");
        System.out.println("├─────────┼────────────────────────────┼────────────────────┼──────────────┼──────┤");
        
        for (Libro libro : libros) {
            System.out.printf("│ %-7d │ %-26s │ %-18s │ %-12s │ %-4d │\n", 
                libro.getId(), 
                truncateString(libro.getTitulo(), 26), 
                truncateString(libro.getAutor(), 18), 
                truncateString(libro.getIsbn(), 12), 
                libro.getAnio());
        }
        
        System.out.println("└─────────┴────────────────────────────┴────────────────────┴──────────────┴──────┘");
        System.out.println();
        esperarEnter();
    }

    public void mostrarUsuarios() {
        System.out.println(USUARIOS_BANNER);
        List<Usuario> usuarios = usuarioRepository.findAll();
        
        if (usuarios.isEmpty()) {
            System.out.println("\nNo hay usuarios registrados en el sistema.\n");
            return;
        }
        
        System.out.println("┌─────────┬────────────────────────────┬──────────────────┬─────────────────────────┐");
        System.out.println("│   ID    │          NOMBRE           │       DNI        │         CORREO          │");
        System.out.println("├─────────┼────────────────────────────┼──────────────────┼─────────────────────────┤");
        
        for (Usuario usuario : usuarios) {
            System.out.printf("│ %-7d │ %-26s │ %-14s │ %-23s │\n", 
                usuario.getId(), 
                truncateString(usuario.getNombre(), 26), 
                truncateString(usuario.getDni(), 14), 
                truncateString(usuario.getCorreo(), 23));
        }
        
        System.out.println("└─────────┴────────────────────────────┴──────────────────┴─────────────────────────┘");
        System.out.println();
        esperarEnter();
    }

    public void mostrarPrestamos() {
        System.out.println(PRESTAMOS_BANNER);
        List<Prestamo> prestamos = prestamoRepository.findAll();
        
        if (prestamos.isEmpty()) {
            System.out.println("\nNo hay préstamos registrados en el sistema.\n");
            return;
        }
        
        System.out.println("┌─────────┬────────────────────────────┬────────────────────────────┬──────────────┬──────────────┐");
        System.out.println("│   ID    │          USUARIO           │           LIBRO            │  PRÉSTAMO    │ DEVOLUCIÓN   │");
        System.out.println("├─────────┼────────────────────────────┼────────────────────────────┼──────────────┼──────────────┤");
        
        for (Prestamo prestamo : prestamos) {
            System.out.printf("│ %-7d │ %-26s │ %-26s │ %-12s │ %-12s │\n", 
                prestamo.getId(), 
                truncateString(prestamo.getUsuario().getNombre(), 26), 
                truncateString(prestamo.getLibro().getTitulo(), 26), 
                prestamo.getFechaPrestamo(), 
                prestamo.getFechaDevolucion());
        }
        
        System.out.println("└─────────┴────────────────────────────┴────────────────────────────┴──────────────┴──────────────┘");
        System.out.println();
        esperarEnter();
    }
    
    // Método auxiliar para truncar strings que son demasiado largos para la tabla
    private String truncateString(String str, int maxLength) {
        if (str == null) {
            return "";
        }
        return str.length() <= maxLength ? str : str.substring(0, maxLength - 3) + "...";
    }
    
    // Método para pausar la visualización hasta que el usuario presione Enter
    private void esperarEnter() {
        System.out.println("Presione Enter para continuar...");
        try {
            System.in.read();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Métodos para la API REST
    public List<Libro> getAllLibros() {
        return libroRepository.findAll();
    }

    public Libro getLibroById(Long id) {
        return libroRepository.findById(id).orElse(null);
    }

    public Libro saveLibro(Libro libro) {
        return libroRepository.save(libro);
    }
    
    public Libro registrarLibro(Libro libro) {
        return libroRepository.save(libro);
    }

    public List<Usuario> getAllUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario getUsuarioById(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    public Usuario saveUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }
    
    public Usuario registrarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public List<Prestamo> getAllPrestamos() {
        return prestamoRepository.findAll();
    }

    public Prestamo getPrestamoById(Long id) {
        return prestamoRepository.findById(id).orElse(null);
    }

    public Prestamo savePrestamo(Prestamo prestamo) {
        return prestamoRepository.save(prestamo);
    }  
    public Prestamo prestarLibro(Long usuarioId, Long libroId, LocalDate fechaPrestamo, LocalDate fechaDevolucion) {
        Usuario usuario = usuarioRepository.findById(usuarioId).orElse(null);
        Libro libro = libroRepository.findById(libroId).orElse(null);
        
        if (usuario != null && libro != null) {
            Prestamo prestamo = new Prestamo(usuario, libro, fechaPrestamo, fechaDevolucion);
            return prestamoRepository.save(prestamo);
        }
        return null;
    }

    public List<Prestamo> getPrestamosByUsuarioId(Long usuarioId) {
        return prestamoRepository.findByUsuarioId(usuarioId);
    }
}