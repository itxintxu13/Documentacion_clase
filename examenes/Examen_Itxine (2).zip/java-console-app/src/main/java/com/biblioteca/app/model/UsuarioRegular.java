package com.biblioteca.app.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("REGULAR")
public class UsuarioRegular extends Usuario {
    
    // Constructor por defecto requerido por JPA
    public UsuarioRegular() {
    }
    
    public UsuarioRegular(String nombre, String dni, String correo) {
        super(nombre, dni, correo);
    }
}