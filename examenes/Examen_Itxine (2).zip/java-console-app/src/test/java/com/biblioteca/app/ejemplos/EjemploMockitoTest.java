package com.biblioteca.app.ejemplos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.biblioteca.app.model.Libro;
import com.biblioteca.app.model.Prestamo;
import com.biblioteca.app.model.Usuario;
import com.biblioteca.app.repository.LibroRepository;
import com.biblioteca.app.repository.PrestamoRepository;
import com.biblioteca.app.repository.UsuarioRepository;
import com.biblioteca.app.service.BibliotecaService;

/**
 * Clase de ejemplo que muestra cómo utilizar Mockito para pruebas unitarias
 * en una aplicación Spring Boot.
 */
@ExtendWith(MockitoExtension.class)
public class EjemploMockitoTest {

    // 1. Anotación @Mock: Crea un mock del objeto especificado
    @Mock
    private LibroRepository libroRepository;
    
    @Mock
    private UsuarioRepository usuarioRepository;
    
    @Mock
    private PrestamoRepository prestamoRepository;
    
    // 2. Anotación @InjectMocks: Inyecta los mocks en el objeto que se está probando
    @InjectMocks
    private BibliotecaService bibliotecaService;
    
    // 3. Anotación @Spy: Crea un espía que permite llamar a métodos reales pero también mockearlos
    @Spy
    private List<Libro> librosSpy = new ArrayList<>();
    
    // 4. Anotación @Captor: Captura argumentos pasados a los métodos mockeados
    @Captor
    private ArgumentCaptor<Libro> libroCaptor;
    
    private Libro libro;
    private Usuario usuario;
    private Prestamo prestamo;
    
    @BeforeEach
    void setUp() {
        // Configuración que se ejecuta antes de cada prueba
        libro = new Libro("El Quijote", "Miguel de Cervantes", "978-84-376-0494-7", 1605);
        usuario = new Usuario("Juan Pérez", "12345678A", "juan@example.com");
        prestamo = new Prestamo(usuario, libro, LocalDate.now(), LocalDate.now().plusDays(14));
    }
    
    @Test
    @DisplayName("Test básico con when-thenReturn")
    void testBasicoWhenThenReturn() {
        // 5. Configuración del comportamiento del mock con when-thenReturn
        when(libroRepository.save(any(Libro.class))).thenReturn(libro);
        
        // Llamada al método que se está probando
        Libro resultado = bibliotecaService.saveLibro(libro);
        
        // Verificaciones
        assertNotNull(resultado);
        assertEquals("El Quijote", resultado.getTitulo());
        
        // 6. Verificar que el método mock fue llamado exactamente una vez
        verify(libroRepository, times(1)).save(any(Libro.class));
    }
    
    @Test
    @DisplayName("Test con doReturn-when como alternativa")
    void testDoReturnWhen() {
        // 7. Configuración alternativa con doReturn-when
        doReturn(libro).when(libroRepository).save(any(Libro.class));
        
        Libro resultado = bibliotecaService.saveLibro(libro);
        
        assertNotNull(resultado);
        assertEquals("El Quijote", resultado.getTitulo());
    }
    
    @Test
    @DisplayName("Test con ArgumentCaptor para capturar argumentos")
    void testArgumentCaptor() {
        // Configurar mock
        when(libroRepository.save(any(Libro.class))).thenReturn(libro);
        
        // Llamar al método
        bibliotecaService.saveLibro(libro);
        
        // 8. Capturar el argumento pasado al método save
        verify(libroRepository).save(libroCaptor.capture());
        
        // Verificar el argumento capturado
        Libro libroCaptured = libroCaptor.getValue();
        assertEquals("El Quijote", libroCaptured.getTitulo());
        assertEquals("Miguel de Cervantes", libroCaptured.getAutor());
    }
    
    @Test
    @DisplayName("Test con múltiples retornos")
    void testMultiplesRetornos() {
        // 9. Configurar múltiples retornos para llamadas consecutivas
        Libro libro1 = new Libro("Libro 1", "Autor 1", "ISBN1", 2001);
        Libro libro2 = new Libro("Libro 2", "Autor 2", "ISBN2", 2002);
        
        when(libroRepository.save(any(Libro.class)))
            .thenReturn(libro1)
            .thenReturn(libro2);
        
        // Primera llamada retorna libro1
        Libro resultado1 = bibliotecaService.saveLibro(new Libro());
        assertEquals("Libro 1", resultado1.getTitulo());
        
        // Segunda llamada retorna libro2
        Libro resultado2 = bibliotecaService.saveLibro(new Libro());
        assertEquals("Libro 2", resultado2.getTitulo());
    }
    
    @Test
    @DisplayName("Test con Optional")
    void testOptional() {
        // 10. Mockear métodos que retornan Optional
        when(libroRepository.findById(1L)).thenReturn(Optional.of(libro));
        when(libroRepository.findById(2L)).thenReturn(Optional.empty());
        
        // Caso donde el libro existe
        Libro resultado = bibliotecaService.getLibroById(1L);
        assertNotNull(resultado);
        assertEquals("El Quijote", resultado.getTitulo());
        
        // Caso donde el libro no existe
        Libro resultadoNull = bibliotecaService.getLibroById(2L);
        assertEquals(null, resultadoNull);
    }
    
    @Test
    @DisplayName("Test con listas")
    void testListas() {
        // 11. Mockear métodos que retornan listas
        List<Libro> libros = Arrays.asList(
            new Libro("Libro 1", "Autor 1", "ISBN1", 2001),
            new Libro("Libro 2", "Autor 2", "ISBN2", 2002)
        );
        
        when(libroRepository.findAll()).thenReturn(libros);
        
        List<Libro> resultados = bibliotecaService.getAllLibros();
        
        assertEquals(2, resultados.size());
        assertEquals("Libro 1", resultados.get(0).getTitulo());
        assertEquals("Libro 2", resultados.get(1).getTitulo());
    }
    
    @Test
    @DisplayName("Test con verify para comprobar interacciones")
    void testVerify() {
        // Llamar al método
        bibliotecaService.saveLibro(libro);
        
        // 12. Verificar que el método fue llamado con el argumento correcto
        verify(libroRepository).save(libro);
        
        // Verificar que otro método no fue llamado
        verify(libroRepository, never()).findById(anyLong());
        
        // Verificar el número exacto de interacciones
        verify(libroRepository, times(1)).save(any(Libro.class));
    }
    
    @Test
    @DisplayName("Test con spy")
    void testSpy() {
        // 13. Trabajar con un spy
        librosSpy.add(new Libro("Libro existente", "Autor", "ISBN", 2000));
        
        // Podemos llamar métodos reales en el spy
        assertEquals(1, librosSpy.size());
        
        // También podemos mockear comportamientos
        doReturn(100).when(librosSpy).size();
        
        // Ahora el método mockeado retorna el valor configurado
        assertEquals(100, librosSpy.size());
    }
    
    @Test
    @DisplayName("Test con excepciones")
    void testExcepciones() {
        // 14. Configurar un mock para lanzar una excepción
        when(libroRepository.findById(anyLong()))
            .thenThrow(new RuntimeException("Error simulado"));
        
        // Verificar que se lanza la excepción
        try {
            bibliotecaService.getLibroById(1L);
            // Si llegamos aquí, la prueba falla
            assertTrue(false, "Debería haber lanzado una excepción");
        } catch (RuntimeException e) {
            assertEquals("Error simulado", e.getMessage());
        }
    }
    
    @Test
    @DisplayName("Test con Mockito.any() y matchers")
    void testMatchers() {
        // 15. Uso de matchers para argumentos
        when(libroRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(libro));
        
        Libro resultado = bibliotecaService.getLibroById(999L); // Cualquier ID funcionará
        
        assertNotNull(resultado);
        assertEquals("El Quijote", resultado.getTitulo());
    }
    
    @Test
    @DisplayName("Test del método prestarLibro")
    void testPrestarLibro() {
        // Configurar datos de prueba
        LocalDate fechaPrestamo = LocalDate.now();
        LocalDate fechaDevolucion = fechaPrestamo.plusDays(14);
        
        // Configurar el comportamiento de los mocks
        when(usuarioRepository.findById(anyLong())).thenReturn(Optional.of(usuario));
        when(libroRepository.findById(anyLong())).thenReturn(Optional.of(libro));
        when(prestamoRepository.save(any(Prestamo.class))).thenReturn(prestamo);
        
        // Llamar al método bajo prueba
        Prestamo resultado = bibliotecaService.prestarLibro(1L, 1L, fechaPrestamo, fechaDevolucion);
        
        // Verificar el resultado
        assertNotNull(resultado);
        assertEquals(libro, resultado.getLibro());
        assertEquals(usuario, resultado.getUsuario());
        assertEquals(fechaPrestamo, resultado.getFechaPrestamo());
        assertEquals(fechaDevolucion, resultado.getFechaDevolucion());
        
        // Verificar que los métodos mock fueron llamados
        verify(usuarioRepository).findById(1L);
        verify(libroRepository).findById(1L);
        verify(prestamoRepository).save(any(Prestamo.class));
    }
}