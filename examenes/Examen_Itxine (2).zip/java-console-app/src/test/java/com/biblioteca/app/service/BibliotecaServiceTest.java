package com.biblioteca.app.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.biblioteca.app.model.Libro;
import com.biblioteca.app.model.Usuario;
import com.biblioteca.app.model.Prestamo;
import com.biblioteca.app.repository.LibroRepository;
import com.biblioteca.app.repository.UsuarioRepository;
import com.biblioteca.app.repository.PrestamoRepository;

import java.time.LocalDate;

@ExtendWith(MockitoExtension.class)
class BibliotecaServiceTest {

    @Mock
    private LibroRepository libroRepository;
    
    @Mock
    private UsuarioRepository usuarioRepository;
    
    @Mock
    private PrestamoRepository prestamoRepository;
    
    @InjectMocks
    private BibliotecaService bibliotecaService;
    
    private Libro libro;
    private Usuario usuario;
    
    @BeforeEach
    void setUp() {
        // Configurar objetos de prueba
        libro = new Libro("Título de prueba", "Autor de prueba", "1234567890", 2023);
        usuario = new Usuario("Usuario de prueba", "12345678A", "usuario@test.com");
    }
    
    @Test
    void testRegistrarLibro() {
        // Configurar el comportamiento del mock
        when(libroRepository.save(any(Libro.class))).thenReturn(libro);
        
        // Llamar al método bajo prueba
        Libro resultado = bibliotecaService.registrarLibro(libro);
        
        // Verificar el resultado
        assertNotNull(resultado);
        assertEquals("Título de prueba", resultado.getTitulo());
        assertEquals("Autor de prueba", resultado.getAutor());
        verify(libroRepository).save(any(Libro.class));
    }
    
    @Test
    void testRegistrarUsuario() {
        // Configurar el comportamiento del mock
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);
        
        // Llamar al método bajo prueba
        Usuario resultado = bibliotecaService.registrarUsuario(usuario);
        
        // Verificar el resultado
        assertNotNull(resultado);
        assertEquals("Usuario de prueba", resultado.getNombre());
        assertEquals("usuario@test.com", resultado.getCorreo());
        verify(usuarioRepository).save(any(Usuario.class));
    }
    
    @Test
    void testPrestarLibro() {
        // Configurar datos de prueba
        LocalDate fechaPrestamo = LocalDate.now();
        LocalDate fechaDevolucion = fechaPrestamo.plusDays(14);
        Prestamo prestamo = new Prestamo(usuario, libro, fechaPrestamo, fechaDevolucion);
        
        // Configurar el comportamiento del mock
        when(libroRepository.findById(any(Long.class))).thenReturn(java.util.Optional.of(libro));
        when(usuarioRepository.findById(any(Long.class))).thenReturn(java.util.Optional.of(usuario));
        when(prestamoRepository.save(any(Prestamo.class))).thenReturn(prestamo);
        
        // Llamar al método bajo prueba
        Prestamo resultado = bibliotecaService.prestarLibro(1L, 1L, fechaPrestamo, fechaDevolucion);
        
        // Verificar el resultado
        assertNotNull(resultado);
        assertEquals(libro, resultado.getLibro());
        assertEquals(usuario, resultado.getUsuario());
        assertEquals(fechaPrestamo, resultado.getFechaPrestamo());
        assertEquals(fechaDevolucion, resultado.getFechaDevolucion());
        verify(prestamoRepository).save(any(Prestamo.class));
    }
}