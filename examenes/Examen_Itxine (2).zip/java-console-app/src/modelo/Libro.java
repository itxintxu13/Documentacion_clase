package modelo;

public class Libro {
    private String titulo;
    private String autor;
    private String isbn;
    private int anio;

    public Libro(String titulo, String autor, String isbn, int anio) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.anio = anio;
    }

    @Override
    public String toString() {
        return titulo + " - " + autor + " (" + anio + ") ISBN: " + isbn;
    }
}