package modelo;

public class Usuario {
    protected String nombre;
    protected String dni;
    protected String correo;

    public Usuario(String nombre, String dni, String correo) {
        this.nombre = nombre;
        this.dni = dni;
        this.correo = correo;
    }

    @Override
    public String toString() {
        return nombre + " - " + dni + " - " + correo;
    }
}