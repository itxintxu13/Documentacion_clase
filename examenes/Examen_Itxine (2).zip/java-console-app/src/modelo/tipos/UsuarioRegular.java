package modelo.tipos;

import modelo.Usuario;

public class UsuarioRegular extends Usuario {
    public UsuarioRegular(String nombre, String dni, String correo) {
        super(nombre, dni, correo);
    }
}