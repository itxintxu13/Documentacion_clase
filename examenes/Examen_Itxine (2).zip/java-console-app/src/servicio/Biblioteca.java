package servicio;

import modelo.*;
import modelo.tipos.UsuarioRegular;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Biblioteca {
    private List<Libro> libros = new ArrayList<>();
    private List<Usuario> usuarios = new ArrayList<>();
    private List<Prestamo> prestamos = new ArrayList<>();

    public void registrarLibro(Scanner sc) {
        System.out.print("Título: ");
        String titulo = sc.nextLine();
        System.out.print("Autor: ");
        String autor = sc.nextLine();
        System.out.print("ISBN: ");
        String isbn = sc.nextLine();
        System.out.print("Año: ");
        int anio = sc.nextInt(); sc.nextLine();
        libros.add(new Libro(titulo, autor, isbn, anio));
        System.out.println("Libro registrado.");
    }

    public void registrarUsuario(Scanner sc) {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("DNI: ");
        String dni = sc.nextLine();
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        usuarios.add(new UsuarioRegular(nombre, dni, correo));
        System.out.println("Usuario registrado.");
    }

    public void prestarLibro(Scanner sc) {
        if (usuarios.isEmpty() || libros.isEmpty()) {
            System.out.println("Debes registrar al menos un usuario y un libro.");
            return;
        }
        System.out.println("Seleccione usuario (índice):");
        for (int i = 0; i < usuarios.size(); i++) System.out.println(i + ": " + usuarios.get(i));
        int idxUsuario = sc.nextInt(); sc.nextLine();

        System.out.println("Seleccione libro (índice):");
        for (int i = 0; i < libros.size(); i++) System.out.println(i + ": " + libros.get(i));
        int idxLibro = sc.nextInt(); sc.nextLine();

        LocalDate hoy = LocalDate.now();
        LocalDate devolucion = hoy.plusDays(15);
        prestamos.add(new Prestamo(usuarios.get(idxUsuario), libros.get(idxLibro), hoy, devolucion));
        System.out.println("Préstamo registrado.");
    }

    public void mostrarLibros() {
        System.out.println("--- Libros ---");
        for (Libro l : libros) System.out.println(l);
    }

    public void mostrarUsuarios() {
        System.out.println("--- Usuarios ---");
        for (Usuario u : usuarios) System.out.println(u);
    }

    public void mostrarPrestamos() {
        System.out.println("--- Préstamos ---");
        for (Prestamo p : prestamos) System.out.println(p);
    }
}