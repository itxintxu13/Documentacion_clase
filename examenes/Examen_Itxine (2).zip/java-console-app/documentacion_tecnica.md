# Documentación Técnica - Sistema de Biblioteca

## 1. Análisis de Requisitos

### Requisitos Funcionales

1. **Gestión de Libros**
   - Registrar nuevos libros con título, autor, ISBN y año
   - Consultar libros existentes

2. **Gestión de Usuarios**
   - Registrar nuevos usuarios con nombre, DNI y correo
   - Consultar usuarios existentes

3. **Gestión de Préstamos**
   - Registrar préstamos de libros a usuarios
   - Establecer fechas de préstamo y devolución
   - Consultar préstamos existentes

4. **Interfaz de Usuario**
   - Interfaz por consola para operaciones básicas
   - API REST para integración con otros sistemas

### Requisitos No Funcionales

1. **Persistencia**
   - Almacenamiento de datos en base de datos relacional
   - Uso de JPA/Hibernate para mapeo objeto-relacional

2. **Arquitectura**
   - Aplicación basada en Spring Boot
   - Arquitectura en capas (controlador, servicio, repositorio, modelo)

3. **Usabilidad**
   - Mantener la interfaz de consola existente
   - Proporcionar API REST para acceso programático

## 2. Diagramas UML

### Diagrama de Clases

```
+-------------------+       +-------------------+       +-------------------+
|      Libro        |       |      Usuario      |       |     Prestamo      |
+-------------------+       +-------------------+       +-------------------+
| -id: Long         |       | -id: Long         |       | -id: Long         |
| -titulo: String   |       | -nombre: String   |       | -fechaPrestamo:   |
| -autor: String    |       | -dni: String      |       |    LocalDate      |
| -isbn: String     |       | -correo: String   |       | -fechaDevolucion: |
| -anio: int        |       +-------------------+       |    LocalDate      |
+-------------------+       | +getTipo(): String |       +-------------------+
                            +-------------------+       | -usuario: Usuario |
                                     ^
                                     |
                            +-------------------+
                            |  UsuarioRegular   |
                            +-------------------+
                            | +getTipo(): String |
                            +-------------------+
```

### Diagrama de Casos de Uso

```
                    +---------------------+
                    |    Sistema de       |
                    |     Biblioteca      |
                    +---------------------+
                              ^
                              |
            +----------------+----------------+
            |                                 |
  +-------------------+             +-------------------+
  |     Usuario       |             |  Administrador    |
  |    de Consola    |             |      de API       |
  +-------------------+             +-------------------+
  | - Registrar libro |             | - Obtener libros  |
  | - Registrar usuario|            | - Obtener usuarios|
  | - Prestar libro   |             | - Obtener préstamos|
  | - Ver libros      |             | - Crear libro     |
  | - Ver usuarios    |             | - Crear usuario   |
  | - Ver préstamos   |             | - Crear préstamo  |
  +-------------------+             +-------------------+
```

## 3. Diseño de Base de Datos (Modelo Entidad-Relación)

```
+---------------+       +---------------+       +---------------+
|     LIBRO     |       |    USUARIO    |       |    PRESTAMO   |
+---------------+       +---------------+       +---------------+
| id (PK)       |       | id (PK)       |       | id (PK)       |
| titulo        |       | nombre        |       | fecha_prestamo|
| autor         |       | dni           |       | fecha_devolucion|
| isbn          |       | correo        |       | usuario_id (FK)|
| anio          |       | tipo          |       | libro_id (FK) |
+---------------+       +---------------+       +---------------+
```

## 4. Planificación del Desarrollo (Cronograma)

| Fase                           | Duración Estimada | Estado     |
|--------------------------------|-------------------|------------|
| Análisis de requisitos         | 1 día             | Completado |
| Diseño de la arquitectura      | 1 día             | Completado |
| Implementación del modelo      | 1 día             | Completado |
| Implementación de repositorios | 0.5 día           | Completado |
| Implementación de servicios    | 1 día             | Completado |
| Implementación de controladores| 0.5 día           | Completado |
| Integración con consola        | 1 día             | Completado |
| Pruebas                        | 1 día             | Completado |
| Documentación                  | 0.5 día           | Completado |

## 5. Pruebas Realizadas

### Pruebas Unitarias

- **Modelo**: Verificación de la correcta creación de entidades y relaciones
- **Repositorio**: Pruebas de operaciones CRUD básicas
- **Servicio**: Pruebas de lógica de negocio

### Pruebas de Integración

- **API REST**: Verificación de endpoints mediante Postman
- **Consola**: Verificación de funcionalidad de consola

### Pruebas de Sistema

- Verificación del flujo completo de registro de libros, usuarios y préstamos
- Verificación de la persistencia de datos

## 6. Instrucciones de Uso

### Ejecución de la Aplicación

1. Clonar el repositorio
2. Ejecutar `mvn clean install` para compilar el proyecto
3. Ejecutar `mvn spring-boot:run` para iniciar la aplicación

### Acceso a la Consola

La aplicación de consola se iniciará automáticamente y mostrará un menú con las opciones disponibles.

### Acceso a la API REST

- **Libros**: `http://localhost:8080/libros`
- **Usuarios**: `http://localhost:8080/usuarios`
- **Préstamos**: `http://localhost:8080/prestamos`
