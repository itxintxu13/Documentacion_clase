# Configuración de la Aplicación de Biblioteca con MySQL

Este documento proporciona instrucciones para configurar y ejecutar la aplicación de biblioteca utilizando MySQL como base de datos.

## Requisitos Previos

1. Java 17 o superior instalado
2. Maven instalado
3. MySQL Server instalado
4. MySQL Workbench (opcional, para gestionar la base de datos visualmente)

## Pasos para Configurar MySQL

### 1. Crear la Base de Datos

La aplicación está configurada para crear automáticamente la base de datos si no existe, pero también puedes crearla manualmente:

```sql
CREATE DATABASE IF NOT EXISTS bibliotecadb;
```

### 2. Configurar Usuario y Contraseña

La aplicación está configurada para conectarse a MySQL con el usuario `root` y la contraseña `1234`. Si tu configuración es diferente, debes modificar el archivo `application.properties`:

```properties
spring.datasource.username=root
spring.datasource.password=1234
```

Cambia estos valores según tu configuración de MySQL.

## Ejecutar la Aplicación

1. Asegúrate de que el servidor MySQL esté en ejecución
2. Desde la raíz del proyecto, ejecuta:

```bash
mvn clean install
mvn spring-boot:run
```

## Verificar la Conexión

1. La aplicación se iniciará y mostrará un mensaje en la consola indicando que está en ejecución
2. La aplicación creará automáticamente las tablas necesarias en la base de datos
3. Puedes verificar la creación de tablas usando MySQL Workbench o el cliente de línea de comandos:

```sql
USE bibliotecadb;
SHOW TABLES;
```

Deberías ver las tablas `libro`, `usuario`, `usuario_regular` y `prestamo`.

## Acceder a la API REST

La API REST estará disponible en:

- http://localhost:8080/libros
- http://localhost:8080/usuarios
- http://localhost:8080/prestamos

## Solución de Problemas

### Error de Conexión a MySQL

Si encuentras errores de conexión, verifica:

1. Que el servidor MySQL esté en ejecución
2. Que el usuario y contraseña en `application.properties` sean correctos
3. Que el puerto de MySQL sea 3306 (puerto por defecto)

### Error de Dialecto

Si encuentras errores relacionados con el dialecto de MySQL, asegúrate de que la versión del conector MySQL en el `pom.xml` sea compatible con tu versión de MySQL Server.