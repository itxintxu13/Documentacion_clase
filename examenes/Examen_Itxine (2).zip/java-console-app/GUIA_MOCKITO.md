# Guía de Uso de Mockito para Pruebas Unitarias en Spring Boot

## Introducción

Mockito es una biblioteca de mocking popular para pruebas unitarias en Java. Permite crear objetos simulados (mocks) de dependencias para aislar el código que se está probando. Esta guía explica cómo utilizar Mockito en pruebas unitarias para aplicaciones Spring Boot.

## Configuración

En un proyecto Spring Boot, Mockito ya está incluido en la dependencia `spring-boot-starter-test`. Si estás utilizando Maven, asegúrate de tener esta dependencia en tu archivo `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

## Conceptos Básicos de Mockito

### 1. Anotaciones Principales

- **@Mock**: Crea un mock del objeto especificado.
- **@InjectMocks**: Inyecta los mocks en el objeto que se está probando.
- **@Spy**: Crea un espía que permite llamar a métodos reales pero también mockearlos.
- **@Captor**: Captura argumentos pasados a los métodos mockeados.
- **@ExtendWith(MockitoExtension.class)**: Habilita las anotaciones de Mockito en JUnit 5.

### 2. Configuración de Comportamiento

- **when-thenReturn**: Configura el comportamiento de un método mockeado.
- **doReturn-when**: Alternativa a when-thenReturn, útil para métodos void.
- **thenThrow**: Configura un método para lanzar una excepción.

### 3. Verificación de Interacciones

- **verify**: Verifica que un método fue llamado.
- **times**: Verifica el número exacto de llamadas.
- **never**: Verifica que un método nunca fue llamado.
- **ArgumentCaptor**: Captura argumentos para verificaciones detalladas.

## Ejemplos Prácticos

### Ejemplo 1: Configuración Básica de una Prueba con Mockito

```java
@ExtendWith(MockitoExtension.class)
class BibliotecaServiceTest {

    @Mock
    private LibroRepository libroRepository;
    
    @InjectMocks
    private BibliotecaService bibliotecaService;
    
    @Test
    void testSaveLibro() {
        // Preparar datos de prueba
        Libro libro = new Libro("Título", "Autor", "ISBN", 2023);
        
        // Configurar comportamiento del mock
        when(libroRepository.save(any(Libro.class))).thenReturn(libro);
        
        // Ejecutar método a probar
        Libro resultado = bibliotecaService.saveLibro(libro);
        
        // Verificar resultado
        assertNotNull(resultado);
        assertEquals("Título", resultado.getTitulo());
        
        // Verificar interacción con el mock
        verify(libroRepository).save(libro);
    }
}
```

### Ejemplo 2: Uso de ArgumentCaptor

```java
@Test
void testArgumentCaptor() {
    // Preparar datos
    Libro libro = new Libro("Título", "Autor", "ISBN", 2023);
    
    // Configurar mock
    when(libroRepository.save(any(Libro.class))).thenReturn(libro);
    
    // Ejecutar método
    bibliotecaService.saveLibro(libro);
    
    // Capturar argumento
    ArgumentCaptor<Libro> libroCaptor = ArgumentCaptor.forClass(Libro.class);
    verify(libroRepository).save(libroCaptor.capture());
    
    // Verificar argumento capturado
    Libro libroCaptured = libroCaptor.getValue();
    assertEquals("Título", libroCaptured.getTitulo());
}
```

### Ejemplo 3: Mockear Métodos que Retornan Optional

```java
@Test
void testFindById() {
    // Preparar datos
    Libro libro = new Libro("Título", "Autor", "ISBN", 2023);
    
    // Configurar mock para retornar Optional con valor
    when(libroRepository.findById(1L)).thenReturn(Optional.of(libro));
    
    // Configurar mock para retornar Optional vacío
    when(libroRepository.findById(2L)).thenReturn(Optional.empty());
    
    // Caso donde el libro existe
    Libro resultado1 = bibliotecaService.getLibroById(1L);
    assertNotNull(resultado1);
    assertEquals("Título", resultado1.getTitulo());
    
    // Caso donde el libro no existe
    Libro resultado2 = bibliotecaService.getLibroById(2L);
    assertNull(resultado2);
}
```

### Ejemplo 4: Mockear Listas

```java
@Test
void testFindAll() {
    // Preparar datos
    List<Libro> libros = Arrays.asList(
        new Libro("Libro 1", "Autor 1", "ISBN1", 2001),
        new Libro("Libro 2", "Autor 2", "ISBN2", 2002)
    );
    
    // Configurar mock
    when(libroRepository.findAll()).thenReturn(libros);
    
    // Ejecutar método
    List<Libro> resultados = bibliotecaService.getAllLibros();
    
    // Verificar resultados
    assertEquals(2, resultados.size());
    assertEquals("Libro 1", resultados.get(0).getTitulo());
    assertEquals("Libro 2", resultados.get(1).getTitulo());
}
```

### Ejemplo 5: Mockear Excepciones

```java
@Test
void testExcepcion() {
    // Configurar mock para lanzar excepción
    when(libroRepository.findById(anyLong()))
        .thenThrow(new RuntimeException("Error simulado"));
    
    // Verificar que se lanza la excepción
    assertThrows(RuntimeException.class, () -> {
        bibliotecaService.getLibroById(1L);
    });
}
```

### Ejemplo 6: Uso de Spy

```java
@Test
void testSpy() {
    // Crear un spy de una lista real
    List<Libro> librosSpy = spy(new ArrayList<>());
    
    // Podemos llamar métodos reales
    librosSpy.add(new Libro("Libro real", "Autor", "ISBN", 2000));
    assertEquals(1, librosSpy.size());
    
    // También podemos mockear comportamientos
    doReturn(100).when(librosSpy).size();
    assertEquals(100, librosSpy.size());
}
```

## Mejores Prácticas

1. **Mantén las pruebas simples**: Prueba una sola funcionalidad por método de prueba.

2. **Usa nombres descriptivos**: Los nombres de los métodos de prueba deben describir lo que se está probando.

3. **Mockea solo lo necesario**: No mockees todo, solo las dependencias externas que no quieres incluir en la prueba.

4. **Evita mockear tipos que no te pertenecen**: Prefiere crear adaptadores para APIs externas y mockear esos adaptadores.

5. **Usa @BeforeEach para configuración común**: Coloca la configuración común en métodos anotados con @BeforeEach.

6. **Verifica interacciones importantes**: Usa verify() para confirmar que los métodos esperados fueron llamados.

7. **Prueba casos límite**: Incluye pruebas para casos límite y escenarios de error.

## Diferencia entre @Mock y @MockBean

- **@Mock**: Es una anotación de Mockito pura, utilizada en pruebas unitarias sin cargar el contexto de Spring.
- **@MockBean**: Es una anotación de Spring Boot Test que crea un mock y lo agrega al contexto de Spring, reemplazando cualquier bean existente del mismo tipo.

## Diferencia entre Pruebas Unitarias y de Integración

- **Pruebas Unitarias con @Mock**: Prueban una unidad de código aislada, sin cargar el contexto de Spring.
- **Pruebas de Integración con @MockBean**: Prueban la integración de componentes cargando el contexto de Spring, pero mockeando algunas dependencias.

## Conclusión

Mockito es una herramienta poderosa para escribir pruebas unitarias efectivas en aplicaciones Spring Boot. Permite aislar el código que se está probando y simular el comportamiento de sus dependencias, lo que facilita la creación de pruebas rápidas y confiables.

Para ver ejemplos más detallados, consulta la clase `EjemploMockitoTest.java` incluida en este proyecto.