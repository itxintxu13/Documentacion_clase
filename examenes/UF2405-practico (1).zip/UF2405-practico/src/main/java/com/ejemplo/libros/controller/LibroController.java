package com.ejemplo.libros.controller;

import com.ejemplo.libros.model.Libro;
import com.ejemplo.libros.repository.LibroDAO;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/libros")
public class LibroController {

    private final LibroDAO libroDAO;

    // ✅ INYECCIÓN POR CONSTRUCTOR
    public LibroController(LibroDAO libroDAO) {
        this.libroDAO = libroDAO;
    }

    @GetMapping
    public String mostrarLibros(Model model) {
        model.addAttribute("libros", libroDAO.findAll());
        return "libros";
    }

    @GetMapping("/nuevo")
    public String mostrarFormulario(Model model) {
        model.addAttribute("libro", new Libro());
        return "formulario";
    }

    @PostMapping("/guardar")
    public String guardarLibro(@Valid @ModelAttribute Libro libro, BindingResult result) {
        if (result.hasErrors()) {
            return "formulario";
        }
        libroDAO.save(libro);
        return "redirect:/libros";
    }
}
